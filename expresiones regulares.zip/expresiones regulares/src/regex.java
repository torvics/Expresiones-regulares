import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regex {
    public static void main(String[] args) {

        String uno = "Hola mundo";
        String dos = "eaaHoLaMunDo Hola mundo HOLA MUNDO HoLa MUNDo";
        String tres = "ea washas sincho la neta lo que es Python";
        String cuatro = "vitorra2004@outlook.com torvic.al100@gmail.com torvicsonamalaya@gmail.com a222217412@unison.mx";
        String cinco = "ISI2027-2.csv";

        Pattern pat = Pattern.compile("Hola mundo");
        Matcher mat = pat.matcher(uno);
        if (mat.matches()){
            System.out.println("la primera cadena sincho");
        } else{
            System.out.println("la primera cadena noncho");
        }


        Pattern pat2 = Pattern.compile("(?i)hola mundo");
        Matcher mat2 = pat2.matcher(dos);
        if (mat2.find()){
            System.out.println("la segunda cadena sincho");
        } else{
            System.out.println("la segunda cadena noncho");
        }


        Pattern pat3 = Pattern.compile("\\b(Java|Python|Go|Pascal|Perl)\\b");
        Matcher mat3 = pat3.matcher(tres);
        if (mat3.matches()){
            System.out.println("la tercera cadena sincho");
        } else{
            System.out.println("la tercera cadena noncho");
        }


        Pattern pat4 = Pattern.compile("(@unison.mx|@uson.mx)%*");
        Matcher mat4 = pat4.matcher(cuatro);
        if (mat4.find()){
            System.out.println("la cuarta cadena sincho");
        } else{
            System.out.println("la cuarta cadena noncho");
        }


        Pattern pat5 = Pattern.compile("^ISI\\w{4}-(1|2).(txt|csv)$");
        Matcher mat5 = pat5.matcher(cinco);
        if (mat5.find()){
            System.out.println("la quinta cadena sincho");
        } else{
            System.out.println("la quinta cadena noncho");
        }


        Pattern pat6 = Pattern.compile("(?i)HolaMundo"); //argumento: HoLaMuNdO
        Matcher mat6 = pat6.matcher(args[0]);
        if (mat6.matches()){
            System.out.println("la sexta cadena sincho");
        } else{
            System.out.println("la sexta cadena noncho");
        }


    }
}